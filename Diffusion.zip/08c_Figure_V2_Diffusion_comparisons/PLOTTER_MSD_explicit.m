figure 
hold

cd torus_explicit
cd torus_explicit_02
c2D7 = load('data_C_time_course');
t2D7 = load('data_time_steps');
cd ..
cd ..

cd ring_explicit
cd ring_explicit_01_D_0p1
c1D7 = load('data_C_time_course');
cd ..
cd ..


MSD1 = nan(1,301);
for i = 1:301
    MSD1(i)= mean((c2D7(60+(i-1)*120,:)-c1D7(i,:)).^2);
end

plot(t2D7,MSD1)


%% Fourier 2D explicit 1D-uFDM comparison

cd unrestricted_explicit
cd dx_0p1_dy_0p1
c1D12 = load('data_C_time_course_1');
cd ..
cd ..

MSD2 = nan(1,301);
for i = 1:301
    MSD2(i)= mean((c2D7(60+(i-1)*120,:)-c1D12(i,:)).^2);
end

plot(t2D7,MSD2)

%% Fourier 2D semi-implicit 1D-uFDM comparison
% 
% cd unrestricted_semi_implicit
% cd dx_0p1_dy_0p1
% c1D19 = load('data_C_time_course_1');
% cd ..
% cd ..
% 
% 
% MSD3 = nan(1,301);
% for i = 1:301
%     MSD3(i)= mean((c2D7(60+(i-1)*120,:)-c1D19(i,:)).^2);
% end
% 
% plot(t2D7,MSD3)

%%

figure;hold
plot(t2D7,MSD1)
yyaxis right
plot(t2D7,MSD2)
% plot(t2D7,MSD3)