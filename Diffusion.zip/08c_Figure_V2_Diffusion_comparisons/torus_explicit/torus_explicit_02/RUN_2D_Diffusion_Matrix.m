% N = 5;

%% x-direction 

Ax = sparse(diag(-2*ones(1,N*M)));
Ax = sparse(Ax + diag(ones(1,N*M - N), N));
Ax = sparse(Ax + diag(ones(1,N*M - N),-N));
Ax = sparse(Ax + diag(ones(1,N)      , N*(M-1)));
Ax = sparse(Ax + diag(ones(1,N)      ,-N*(M-1)));

% figure
% subplot(1,3,1)
% spy(Ax)
% title('Ax')

%% y-direction

% sub-matrix
ay = sparse(diag(-2*ones(1,N)));
ay = sparse(ay + diag(ones(1,N-1),1));
ay = sparse(ay + diag(ones(1,N-1),-1));
ay(1,N) = 1;
ay(N,1) = 1;

% subplot(1,3,2)
% spy(ay)
% title('ay')

% complete matrix
Ay = eye(M);
Ay = kron(Ay,ay);

% subplot(1,3,3)
% spy(Ay)
% title('Ay')

%% complete

dx = Dm*Dt/(Dx^2);
dy = Dm*Dt/(Dy^2);
A = sparse((dx*Ax)+(dy*Ay));
A = sparse(A+eye(N*M));

clear Ax
clear ay
clear Ay