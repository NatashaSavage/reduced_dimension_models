%% Diffusion only torus


%% Storage files
C_store = fopen('data_C_time_course',   'w');  % protein profile
m_store = fopen('data_mass_time_course','w');  % protein mass
T_store = fopen('data_time_steps',   'w');  % protein profile time

% End storage files
%% Setting parameters & initial conditions

L    = 12;      % size of membrane (um)
Dx   = 0.1;     % grid size (um)
Dy   = 0.1;     % grid size (um)
N    = L/Dx;    % number of bins
M    = L/Dy;    % number of bins
Dm   = 0.1;     % Diffusion coefficient ( (um^2)/s )
Ttot = 5*60;    % Simulation time (s)
Dt   = 0.01;    % Time step
Ns   = Ttot/Dt; % number of time steps in the simulation

% check for convergence 1D
if Dy < sqrt(Dt*Dm)
    disp('no convergence')    
end    

% Initial conditions: patch
% Distance of all bins from the centre 
% Distance of all bins from the centre
XX = repmat(Dx*[0.5-N/2:1:N/2-0.5] ,M,1);
YY = repmat(Dy*[  1-M/2:1:M/2    ]',1,N);
% Concentration in 2D 
C = exp(-(XX.^2)-(YY.^2)); % initial condition

% surf(C)
% shading flat
% pause()

% Diffusion matrix 
RUN_2D_Diffusion_Matrix


% pcolor(C);shading flat
% pause()

% End of setting parameters & initial conditions
%% Time stepping

%figure
%PLOTTER_peak_central_slice
%PLOTTER_2D_profile
T = 0;
RUN_write_to_files_2D

for i = 1:Ns
    
    % Diffusing
    Cr = reshape(C,[N*M,1]);
    Cr = A*Cr;
    C  = reshape(Cr,[M,N]);
    
    if mod(i*Dt,1) < Dt-(Dt/100)
        T = i*Dt;
        %PLOTTER_peak_central_slice
        %PLOTTER_2D_profile
        RUN_write_to_files_2D
        save output.mat
    end
    
    
end

%% End of time stepping

fclose all