figure 
hold

cd torus_implicit_01_Dt_0p01
m = load('data_C_time_course');
m = m(60:120:end,:);
m = (mean(m'));
plot([0:300],m)
cd ..

cd ring_implicit_01_Dt_0p01
m = load('data_C_time_course');
%t = load('data_time_steps');
m = (mean(m'));
plot([0:300],m)
cd ..

cd unrestricted_semi_implicit_Dt_0p01
cd dx_0p1_dy_0p1
m = load('data_C_time_course_1');
t = load('data_time_steps_1');
m = (mean(m'));
plot(t,m)
cd ..
cd ..

% cd unrestricted_semi_implicit
% cd dx_0p1_dy_0p1
% m = load('data_C_time_course_1');
% t = load('data_time_steps_1');
% m = (mean(m'));
% plot(t,m)
% cd ..
% cd ..