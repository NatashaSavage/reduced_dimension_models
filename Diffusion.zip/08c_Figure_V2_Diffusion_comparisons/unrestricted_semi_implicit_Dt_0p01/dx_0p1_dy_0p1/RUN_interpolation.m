
%% C1


% CJ will hold the concentration estimate of all points in the 
% Y = k+1(or k-1) plane
CJ = nan(1,N);                

% Interpolating                
CJ = interp1(II,C,lz,'spline');
ind = find(CJ<0);
CJ(ind) = 0;

% checking for nan                
ind = find(isnan(CJ));
if ind
    itp = 0; 
end

