%% Diffusion only program 
%  1D



% End storage files
%% Setting parameters & initial conditions

L    = 12;              % size of membrane (um)
Dx   = 0.1;             % grid size (um)
Dy   = 0.1;             % grid size (um)
Dm   = 0.1;             % Diffusion coefficient ( (um^2)/s )
Ttot = 5*60;            % Simulation time (s)
N    = ceil(L/Dx);      % number of bins
FNc  = 0;

for Dt = [0.01]
    
        
    %% opening files
    FNc = FNc+1;
    filename = sprintf('%s_%d','data_C_time_course',FNc);
    C_store = fopen(filename,   'w');  % protein profile
    filename = sprintf('%s_%d','data_time_steps',FNc);
    T_store = fopen(filename,   'w');  % protein profile
    filename = sprintf('%s_%d','data_mass_time_course',FNc);
    m_store = fopen(filename,   'w');  % protein profile        

    %%

    itp = 1; % no nans so carry on 

    Ns   = Ttot/Dt; % number of time steps in the simulation

    % Diffusion matrix 
    dx = Dm*Dt/(Dx^2);
    dy = Dm*Dt/(Dy^2);
    A = (1-2*dx)*eye(N);
    Ap = dx*diag(ones(1,N-1),1);
    Am = dx*diag(ones(1,N-1),-1);
    A = A + Ap + Am;
    A(1,N) = dx;
    A(N,1) = dx;
    A = sparse(A);

    % check for convergence 1D
    if (2*dx)+dy > 1
        disp('no convergence')
        disp('[dx, dy, (2*dx)+dy] = ')
        [dx, dy, (2*dx)+dy]
    end

    % Initial conditions 
    C = exp(-(Dx*[0.5-N/2:1:N/2-0.5]').^2);

    %% Interpolation mesh 
    % The mesh we will be interpolating from.
    II =      Dx*[0.5-N/2:1:N/2-0.5];  

    % the mesh we will be interpolating to
    % Distance from the center, of all points in the Y = k+1(
    % or k-1) plane. 
    lz = sqrt(II.^2 + Dy^2);


    %% Interpolating

    RUN_interpolation 

    % End of setting parameters & initial conditions
    %% Time stepping

    T = 0;
    RUN_write_to_files_savage_1D

    for i = 1:Ns

        if itp
            C = A*C + 2*dy*(CJ'-C);

            % Interpolating
            RUN_interpolation   

            if mod(i*Dt,1) < Dt-(Dt/100)
                T = i*Dt;
                RUN_write_to_files_savage_1D
                filename = sprintf('%s_%d','output',FNc);
                save(filename)
            end

        end

    end

    fclose all;
    %% End of time stepping
        


end % Dt = ...