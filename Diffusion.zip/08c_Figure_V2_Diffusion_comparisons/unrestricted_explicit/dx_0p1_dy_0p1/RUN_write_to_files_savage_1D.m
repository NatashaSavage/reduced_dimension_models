%% Writing membrane concentrations to file


    fprintf(C_store,'%5.4f\t',C);
    fprintf(C_store,'\n');
    
    fprintf(T_store,'%5.4f\n',T);
    




Ctot = mean(C);
fprintf(m_store,'%5.4f\n', Ctot);



