figure 
hold

cd torus_implicit_01_Dt_0p01
c2D7 = load('data_C_time_course');
t2D7 = load('data_time_steps');
cd ..

cd ring_implicit_01_Dt_0p01
c1D7 = load('data_C_time_course');
cd ..


MSD1 = nan(1,301);
for i = 1:301
    MSD1(i)= mean((c2D7(60+(i-1)*120,:)-c1D7(i,:)).^2);
end

plot(t2D7,MSD1)


%% Fourier 2D explicit 1D-uFDM comparison

cd unrestricted_semi_implicit_Dt_0p01
cd dx_0p1_dy_0p1
c1D12 = load('data_C_time_course_1');
cd ..
cd ..

MSD2 = nan(1,301);
for i = 1:301
    MSD2(i)= mean((c2D7(60+(i-1)*120,:)-c1D12(i,:)).^2);
end

plot(t2D7,MSD2)

%% Fourier 2D semi-implicit 1D-uFDM comparison
% 
% cd unrestricted_semi_implicit
% cd dx_0p1_dy_0p1
% c1D19 = load('data_C_time_course_1');
% cd ..
% cd ..
% 
% 
% MSD3 = nan(1,301);
% for i = 1:301
%     MSD3(i)= mean((c2D7(60+(i-1)*120,:)-c1D19(i,:)).^2);
% end
% 
% plot(t2D7,MSD3)

%%

figure;hold
plot(t2D7,MSD1)
yyaxis right
plot(t2D7,MSD2)
% plot(t2D7,MSD3)