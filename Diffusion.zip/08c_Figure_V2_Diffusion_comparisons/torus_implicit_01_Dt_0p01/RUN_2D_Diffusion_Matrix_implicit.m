% N = 5;

%% x-direction 

Ax = sparse(diag(2*ones(1,N^2)));
Ax = sparse(Ax - diag(ones(1,N^2 - N), N));
Ax = sparse(Ax - diag(ones(1,N^2 - N),-N));
Ax = sparse(Ax - diag(ones(1,N)      , N*(N-1)));
Ax = sparse(Ax - diag(ones(1,N)      ,-N*(N-1)));

% figure
% subplot(1,3,1)
% spy(Ax)
% title('Ax')

%% y-direction

% sub-matrix
ay = sparse(diag(2*ones(1,N)));
ay = sparse(ay - diag(ones(1,N-1),1));
ay = sparse(ay - diag(ones(1,N-1),-1));
ay(1,N) = -1;
ay(N,1) = -1;

% subplot(1,3,2)
% spy(ay)
% title('ay')

% complete matrix
Ay = eye(N);
Ay = kron(Ay,ay);

% subplot(1,3,2)
% spy(Ay)
% title('Ay')

%% complete

d = Dm*Dt/(Dx^2);
A = sparse(d*(Ax+Ay));
A = sparse(A+eye(N^2));

clear Ax
clear ay
clear Ay