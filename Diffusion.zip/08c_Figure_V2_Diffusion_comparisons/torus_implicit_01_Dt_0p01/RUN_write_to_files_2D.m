%% Writing membrane concentrations to file

for i = 1:N
    fprintf(C_store,'%5.4f\t',C(i,:));
    fprintf(C_store,'\n');
end

fprintf(T_store,'%5.4f\n',T);

% End writing membrane concentrations to file
%% Calculate protein mass & write to file

Ctot = sum(sum(C))/L/L;
fprintf(m_store,'%5.4f\t', Ctot);

Ctot = mean(C(N/2,:));
fprintf(m_store,'%5.4f\n', Ctot);

% End calculate protein mass & write to file
