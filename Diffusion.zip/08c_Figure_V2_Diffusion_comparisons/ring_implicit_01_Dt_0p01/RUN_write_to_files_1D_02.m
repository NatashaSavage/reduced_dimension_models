%% Writing membrane concentrations to file

fprintf(C_store,'%5.4f\t',C');
fprintf(C_store,'\n');

% End writing membrane concentrations to file

%% time 



%% Calculate protein mass & write to file

Ctot = mean(C);
fprintf(m_store,'%5.4f\n', Ctot);

% End calculate protein mass & write to file
