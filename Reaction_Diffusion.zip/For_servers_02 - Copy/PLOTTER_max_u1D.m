%% plotting peak

N = 120;
figure;hold

cd Savage1D_2D_explicit_comparison_05b_03a_1D_splineFL_RD_04b
load CC1S.mat
plot(CC1S(:,N/2))
cd ..

cd Savage1D_2D_explicit_comparison_05b_03a_1D_splineFL_RD_04a
load CC1S.mat
plot(CC1S(:,N/2))
cd ..

cd Savage1D_2D_explicit_comparison_05b_03a_1D_splineFL_RD_04c
load CC1S.mat
plot(CC1S(:,N/2))
cd ..

cd Savage1D_2D_explicit_comparison_05b_03a_1D_splineFL_RD_04d
load CC1S.mat
plot(CC1S(:,N/2))
cd ..

cd Savage1D_2D_explicit_comparison_05b_03a_1D_splineFL_RD_04e
load CC1S.mat
plot(CC1S(:,N/2))
cd ..

cd Savage1D_2D_explicit_comparison_05b_03a_1D_splineFL_RD_04f
load CC1S.mat
plot(CC1S(:,N/2))
cd ..