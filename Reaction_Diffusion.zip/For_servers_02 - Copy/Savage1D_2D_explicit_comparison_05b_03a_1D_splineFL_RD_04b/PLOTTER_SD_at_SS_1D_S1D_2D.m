%% plotting peak

load('output.mat')

load('CC1S')
load('CC2S')
load('CC2')
load('CC1')
load('C11D')
load('C21D')

SDC1 = (C11D - CC1(N/2:N:end,:)).^2;
SDC2 = (C21D - CC2(N/2:N:end,:)).^2;

SDC1S = (CC1S - CC1(N/2:N:end,:)).^2;
SDC2S = (CC2S - CC2(N/2:N:end,:)).^2;



%% 

figure; hold
plot(SDC1(end,:));shading flat
title('C1 MSD 1Dv2D')
ylabel('MSD')

plot(SDC1S(end,:));shading flat
title('C1 MSD S1Dv2D')
ylabel('MSD')

figure;hold
plot(SDC2(end,:));shading flat
title('C2 MSD 1Dv2D')
ylabel('MSD')

plot(SDC2S(end,:));shading flat
title('C2 MSD S1Dv2D')
ylabel('MSD')

%%

figure; hold
plot(sqrt(SDC1(end,:)));shading flat
title('C1 MSD 1Dv2D')
ylabel('MSD')

plot(sqrt(SDC1S(end,:)));shading flat
title('C1 MSD S1Dv2D')
ylabel('MSD')

figure;hold
plot(sqrt(SDC2(end,:)));shading flat
title('C2 MSD 1Dv2D')
ylabel('MSD')

plot(sqrt(SDC2S(end,:)));shading flat
title('C2 MSD S1Dv2D')
ylabel('MSD')
