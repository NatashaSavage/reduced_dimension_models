%% plotting peak

load('output.mat')

load('CC1S')
load('CC2S')
load('CC2')
load('CC1')
load('C11D')
load('C21D')

figure
subplot(2,3,2);pcolor(C11D);shading flat
colormap(jet)
colorbar
title('C1 1D')
xlabel('Distance (um)')
ylabel('Time (s)')
xticks([1 N/2 N])
xticklabels({'0', '6', '12'})
c = colorbar;
c.Label.String = 'Protein Concentration (uM)';

subplot(2,3,5);pcolor(C21D);shading flat
colormap(jet)
colorbar
title('C2 1D')
xlabel('Distance (um)')
ylabel('Time (s)')
xticks([1 N/2 N])
xticklabels({'0', '6', '12'})
c = colorbar;
c.Label.String = 'Protein Concentration (uM)';

subplot(2,3,3);pcolor(CC1S);shading flat
colormap(jet)
colorbar
title('C1 Savage 1D')
xlabel('Distance (um)')
ylabel('Time (s)')
xticks([1 N/2 N])
xticklabels({'0', '6', '12'})
c = colorbar;
c.Label.String = 'Protein Concentration (uM)';

subplot(2,3,6);pcolor(CC2S);shading flat
colormap(jet)
colorbar
title('C2 Savage 1D')
xlabel('Distance (um)')
ylabel('Time (s)')
xticks([1 N/2 N])
xticklabels({'0', '6', '12'})
c = colorbar;
c.Label.String = 'Protein Concentration (uM)';

subplot(2,3,1);pcolor(CC1(N/2:N:end,:));shading flat
colormap(jet)
colorbar
title('C1 2D')
xlabel('Distance (um)')
ylabel('Time (s)')
xticks([1 N/2 N])
xticklabels({'0', '6', '12'})
c = colorbar;
c.Label.String = 'Protein Concentration (uM)';

subplot(2,3,4);pcolor(CC2(N/2:N:end,:));shading flat
colormap(jet)
colorbar
title('C2 2D')
xlabel('Distance (um)')
ylabel('Time (s)')
xticks([1 N/2 N])
xticklabels({'0', '6', '12'})
c = colorbar;
c.Label.String = 'Protein Concentration (uM)';



