%% plotting peak

load('output.mat')

load('CC1S')
load('CC2S')
load('CC2')
load('CC1')
load('C11D')
load('C21D')

figure;hold
a3 = plot(C11D(end,:)); M3 = " 1D";
a1 = plot(C1S); M1 = "Savage 1D";
a2 = plot(C1(N/2,:)); M2 = "2D";
box 'on'
title('C1')
xlabel('Distance (um)')
ylabel('Protein Concentration (uM)')
xticks([1 N/2 N])
xticklabels({'0', '6', '12'})
legend([a3,a1,a2], [M3, M1, M2]);

figure;hold
a3 = plot(C21D(end,:)); M3 = " 1D";
a1 = plot(C2S); M1 = "Savage 1D";
a2 = plot(C2(N/2,:)); M2 = "2D";
box 'on'
xlabel('Distance (um)')
ylabel('Protein Concentration (uM)')
xticks([1 N/2 N])
xticklabels({'0', '6', '12'})
legend([a3,a1,a2], [M3, M1, M2]);

