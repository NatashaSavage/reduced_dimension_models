%% plotting peak

N = 120;
figure;hold
i = 0;

cd Savage1D_2D_explicit_comparison_05b_03a_1D_splineFL_RD_04b
load C11D.mat
i = i+1;
plot(C11D(:,N/2),'LineWidth',3,'Color',[1-i*1.6/10 1-i*1.6/10 i*1.6/20])
cd ..

cd Savage1D_2D_explicit_comparison_05b_03a_1D_splineFL_RD_04a
load C11D.mat
i = i+1;
plot(C11D(:,N/2),'LineWidth',3,'Color',[1-i*1.6/10 1-i*1.6/10 i*1.6/20])
cd ..

cd Savage1D_2D_explicit_comparison_05b_03a_1D_splineFL_RD_04c
load C11D.mat
i = i+1;
plot(C11D(:,N/2),'LineWidth',3,'Color',[1-i*1.6/10 1-i*1.6/10 i*1.6/20])
cd ..

cd Savage1D_2D_explicit_comparison_05b_03a_1D_splineFL_RD_04d
load C11D.mat
i = i+1;
plot(C11D(:,N/2),'LineWidth',3,'Color',[1-i*1.6/10 1-i*1.6/10 i*1.6/20])
cd ..

cd Savage1D_2D_explicit_comparison_05b_03a_1D_splineFL_RD_04e
load C11D.mat
i = i+1;
plot(C11D(:,N/2),'LineWidth',3,'Color',[1-i*1.6/10 1-i*1.6/10 i*1.6/20])
cd ..

cd Savage1D_2D_explicit_comparison_05b_03a_1D_splineFL_RD_04f
load C11D.mat
i = i+1;
plot(C11D(:,N/2),'LineWidth',3,'Color',[1-i*1.6/10 1-i*1.6/10 i*1.6/20])
cd ..

xlim([0 900])