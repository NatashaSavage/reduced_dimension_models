%% plotting peak

N = 120;
figure;hold
i = 0;

cd Savage1D_2D_explicit_comparison_05b_03a_1D_splineFL_RD_04b
load CC1.mat
i = i+1;
plot(CC1(N/2:N:end,N/2),'LineWidth',3,'Color',[1-i*1.6/10 1-i*1.6/10 i*1.6/20])
%plot([0.01:0.01:0.06,0.08,0.1],coco_ex(i,:),'LineWidth',1+i*0.2,'Color',[i*0.9/10 i*0.9/10 i*0.9/10])
cd ..

cd Savage1D_2D_explicit_comparison_05b_03a_1D_splineFL_RD_04a
load CC1.mat
i = i+1;
plot(CC1(N/2:N:end,N/2),'LineWidth',3,'Color',[1-i*1.6/10 1-i*1.6/10 i*1.6/20])
cd ..

cd Savage1D_2D_explicit_comparison_05b_03a_1D_splineFL_RD_04c
load CC1.mat
i = i+1;
plot(CC1(N/2:N:end,N/2),'LineWidth',3,'Color',[1-i*1.6/10 1-i*1.6/10 i*1.6/20])
cd ..

cd Savage1D_2D_explicit_comparison_05b_03a_1D_splineFL_RD_04d
load CC1.mat
i = i+1;
plot(CC1(N/2:N:end,N/2),'LineWidth',3,'Color',[1-i*1.6/10 1-i*1.6/10 i*1.6/20])
cd ..

cd Savage1D_2D_explicit_comparison_05b_03a_1D_splineFL_RD_04e
load CC1.mat
i = i+1;
plot(CC1(N/2:N:end,N/2),'LineWidth',3,'Color',[1-i*1.6/10 1-i*1.6/10 i*1.6/20])
cd ..

cd Savage1D_2D_explicit_comparison_05b_03a_1D_splineFL_RD_04f
load CC1.mat
i = i+1;
plot(CC1(N/2:N:end,N/2),'LineWidth',3,'Color',[1-i*1.6/10 1-i*1.6/10 i*1.6/20])
cd ..

xlim([0 900])