%% plotting peak

N = 120;
%figure;hold
A = [];
B = [];
C = [];



cd Savage1D_2D_explicit_comparison_05b_03a_1D_splineFL_RD_04b
load CC2S.mat
plot3([0.1:0.1:12],0.5*ones(1,120),CC2S(end,:),'k')
scatter3([0.1:0.1:12],0.5*ones(1,120),CC2S(end,:),500,CC2S(end,:),'filled')
cd ..

A = [A;[0.1:0.1:12]];
B = [B; 0.5*ones(1,120)];
C = [C; CC2S(end,:)];

cd Savage1D_2D_explicit_comparison_05b_03a_1D_splineFL_RD_04a
load CC2S.mat
plot3([0.1:0.1:12],ones(1,120),CC2S(end,:),'k')
scatter3([0.1:0.1:12],ones(1,120),CC2S(end,:),500,CC2S(end,:),'filled')
cd ..

A = [A;[0.1:0.1:12]];
B = [B; 1*ones(1,120)];
C = [C; CC2S(end,:)];

cd Savage1D_2D_explicit_comparison_05b_03a_1D_splineFL_RD_04c
load CC2S.mat
plot3([0.1:0.1:12],1.5*ones(1,120),CC2S(end,:),'k')
scatter3([0.1:0.1:12],1.5*ones(1,120),CC2S(end,:),500,CC2S(end,:),'filled')
cd ..

A = [A;[0.1:0.1:12]];
B = [B; 1.5*ones(1,120)];
C = [C; CC2S(end,:)];

cd Savage1D_2D_explicit_comparison_05b_03a_1D_splineFL_RD_04d
load CC2S.mat
plot3([0.1:0.1:12],2*ones(1,120),CC2S(end,:),'k')
scatter3([0.1:0.1:12],2*ones(1,120),CC2S(end,:),500,CC2S(end,:),'filled')
cd ..

A = [A;[0.1:0.1:12]];
B = [B; 2*ones(1,120)];
C = [C; CC2S(end,:)];

cd Savage1D_2D_explicit_comparison_05b_03a_1D_splineFL_RD_04e
load CC2S.mat
plot3([0.1:0.1:12],2.5*ones(1,120),CC2S(end,:),'k')
scatter3([0.1:0.1:12],2.5*ones(1,120),CC2S(end,:),500,CC2S(end,:),'filled')
cd ..

A = [A;[0.1:0.1:12]];
B = [B; 2.5*ones(1,120)];
C = [C; CC2S(end,:)];

cd Savage1D_2D_explicit_comparison_05b_03a_1D_splineFL_RD_04f
load CC2S.mat
plot3([0.1:0.1:12],3*ones(1,120),CC2S(end,:),'k')
scatter3([0.1:0.1:12],3*ones(1,120),CC2S(end,:),500,CC2S(end,:),'filled')
cd ..

A = [A;[0.1:0.1:12]];
B = [B; 3*ones(1,120)];
C = [C; CC2S(end,:)];

view(0,90)
colormap(jet)
caxis([0,0.22])