%% Writing membrane concentrations to file


    fprintf(C1_store1D,'%5.4f\t',C11D');
    fprintf(C1_store1D,'\n');
    
    fprintf(C2_store1D,'%5.4f\t',C21D');
    fprintf(C2_store1D,'\n');    
    
    
    




Ctot = (mean(C21D) + mean(C11D));
fprintf(m_store1D,'%5.4f\n', Ctot);



