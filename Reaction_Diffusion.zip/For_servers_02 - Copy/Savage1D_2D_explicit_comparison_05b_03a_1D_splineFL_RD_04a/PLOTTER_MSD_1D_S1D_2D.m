%% plotting peak

% load('output.mat')
% CC1S = load('data_C1_time_course_S1D');
% CC2S = load('data_C2_time_course_S1D');
% CC1 = load('data_C1_time_course_2D');
% CC2 = load('data_C2_time_course_2D');
% C11D = load('data_C1_time_course_1D');
% C21D = load('data_C2_time_course_1D');

SDC1 = (C11D - CC1(N/2:N:end,:)).^2;
SDC2 = (C21D - CC2(N/2:N:end,:)).^2;

SDC1S = (CC1S - CC1(N/2:N:end,:)).^2;
SDC2S = (CC2S - CC2(N/2:N:end,:)).^2;

MSDC1 = mean(SDC1');
MSDC2 = mean(SDC2');

MSDC1S = mean(SDC1S');
MSDC2S = mean(SDC2S');

%% kymographs

figure
subplot(2,2,1);pcolor(SDC1);shading flat
colormap(jet)
colorbar
title('C1 SD 1Dv2D')
xlabel('Distance (um)')
ylabel('Time (s)')
xticks([1 N/2 N])
xticklabels({'0', '6', '12'})
c = colorbar;
c.Label.String = 'Protein Concentration (uM)';

subplot(2,2,2);pcolor(SDC2);shading flat
colormap(jet)
colorbar
title('C2 SD 1Dv2D')
xlabel('Distance (um)')
ylabel('Time (s)')
xticks([1 N/2 N])
xticklabels({'0', '6', '12'})
c = colorbar;
c.Label.String = 'Protein Concentration (uM)';

subplot(2,2,3);pcolor(SDC1S);shading flat
colormap(jet)
colorbar
title('C1 SD S1Dv2D')
xlabel('Distance (um)')
ylabel('Time (s)')
xticks([1 N/2 N])
xticklabels({'0', '6', '12'})
c = colorbar;
c.Label.String = 'Protein Concentration (uM)';

subplot(2,2,4);pcolor(SDC2S);shading flat
colormap(jet)
colorbar
title('C2 SD S1Dv2D')
xlabel('Distance (um)')
ylabel('Time (s)')
xticks([1 N/2 N])
xticklabels({'0', '6', '12'})
c = colorbar;
c.Label.String = 'Protein Concentration (uM)';

%% 

figure
subplot(2,2,1);plot(MSDC1);shading flat
title('C1 MSD 1Dv2D')
xlabel('Time (s)')
ylabel('MSD')

subplot(2,2,2);plot(MSDC2);shading flat
title('C2 MSD 1Dv2D')
xlabel('Time (s)')
ylabel('MSD')

subplot(2,2,3);plot(MSDC1S);shading flat
title('C1 MSD S1Dv2D')
xlabel('Time (s)')
ylabel('MSD')

subplot(2,2,4);plot(MSDC2S);shading flat
title('C2 MSD S1Dv2D')
xlabel('Time (s)')
ylabel('MSD')
