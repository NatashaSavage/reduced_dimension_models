%% Writing membrane concentrations to file

for i = 1:N
    fprintf(C1_store2D,'%5.4f\t',C1(i,:));
    fprintf(C1_store2D,'\n');

    fprintf(C2_store2D,'%5.4f\t',C2(i,:));
    fprintf(C2_store2D,'\n');
end

% End writing membrane concentrations to file
%% Calculate protein mass & write to file

Ctot = (mean(mean(C2)) + mean(mean(C1)));
fprintf(m_store2D,'%5.4f\t', Ctot);

Ctot = (mean(C2(N/2,:)) + mean(C1(N/2,:)));
fprintf(m_store2D,'%5.4f\n', Ctot);

% End calculate protein mass & write to file
