%% plotting max

% load('output.mat')
% CC1S = load('data_C1_time_course_S1D');
% %CC2S = load('data_C2_time_course_S1D');
% CC1 = load('data_C1_time_course_2D');
% %CC2 = load('data_C2_time_course_2D');
% C11D = load('data_C1_time_course_1D');
% %C21D = load('data_C2_time_course_1D');
T  = load('data_time_steps');

figure
hold


% m = [];
% for i = 1:length(T)
%    
%     mm = max(C11D(i,:));
%     m = [m,mm(1)];
%     
% end
% 
% plot(T,m)

plot(T,C11D(:,N/2))

plot(T,CC1S(:,N/2))

% axis([1,N,0,20])
title('Diffusion in 1D, max concentration')
ylabel('Protein Concentration (uM)')
xlabel('Time (s)')
% xticks([1 N/2 N])
% xticklabels({'0', '5', '10'})

m = [];
for i = 0:length(T)-1
   
    mm = (CC1((M*i)+(M/2),N/2));
    m = [m,mm(1)];
    
end

plot(T,m)
