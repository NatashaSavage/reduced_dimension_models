%% Writing membrane concentrations to file


    fprintf(C1_storeS1D,'%5.4f\t',C1S');
    fprintf(C1_storeS1D,'\n');
    
    fprintf(C2_storeS1D,'%5.4f\t',C2S');
    fprintf(C2_storeS1D,'\n');    
    
    fprintf(T_store,'%5.4f\n',T);
    




Ctot = (mean(C2S) + mean(C1S));
fprintf(m_storeS1D,'%5.4f\n', Ctot);



