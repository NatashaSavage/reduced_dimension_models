%% plotting peak in central slice

load('output.mat')
M1D = load('data_mass_time_course_1D');
MS1D = load('data_mass_time_course_S1D');
M2D = load('data_mass_time_course_2D');
T  = load('data_time_steps');

figure
hold
plot(T,M1D)
plot(T,MS1D)
plot(T,M2D(:,2))



