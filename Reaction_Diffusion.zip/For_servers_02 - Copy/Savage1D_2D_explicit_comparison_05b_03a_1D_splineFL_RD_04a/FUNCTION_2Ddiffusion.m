function [C] = FUNCTION_2Ddiffusion(C,dx,dy,N,M)

    Ctemp = nan(M,N);

    % looping over the middle rows
    for m = 2:M-1

        Ctemp(m,:) = C(m,:) + dx*( [C(m,end) C(m,1:end-1)] - 2*C(m,:) + [C(m,2:end) C(m,1)] ) ...
                            + dy*(  C(m-1,:)               - 2*C(m,:) +  C(m+1,:)           );

    end %for m = 2:M-1

    % row 1
    Ctemp(1,:) = C(1,:) + dx*( [C(1,end) C(1,1:end-1)] - 2*C(1,:) + [C(1,2:end) C(1,1)] ) ...
                        + dy*(  C(M,:)                 - 2*C(1,:) +  C(2,:)             );

    % row M
    Ctemp(M,:) = C(M,:) + dx*( [C(M,end) C(M,1:end-1)] - 2*C(M,:) + [C(M,2:end) C(M,1)] ) ...
                        + dy*(  C(M-1,:)               - 2*C(M,:) +  C(1,:)             );

    C = Ctemp;

end