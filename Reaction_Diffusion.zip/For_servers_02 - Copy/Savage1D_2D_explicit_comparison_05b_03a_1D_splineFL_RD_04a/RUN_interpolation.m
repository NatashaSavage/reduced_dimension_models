
%% C1


% CJ will hold the concentration estimate of all points in the 
% Y = k+1(or k-1) plane
CJ1 = nan(1,N);                

% Interpolating                
CJ1 = interp1(II,C1S,lz,'spline');
% CJ1 = interp1(II,C1S,lz,'linear');
ind = find(CJ1<0);
CJ1(ind) = 0;

% checking for nan                
ind = find(isnan(CJ1));
if ind
%     disp('CJ1')
%     ind
    %CJ1(1)=CJ1(2);
%    CJ1(N)=CJ1(N-1);
     disp('nan, simulation paused CJ1')
     pause()
end

%% C2


% CJ will hold the concentration estimate of all points in the 
% Y = k+1(or k-1) plane
CJ2 = nan(1,N);                

% Interpolating                
CJ2 = interp1(II,C2S,lz,'spline');
%CJ2 = interp1(II,C2S,lz,'linear');
ind = find(CJ2<0);
CJ2(ind) = 0;

% checking for nan                
ind = find(isnan(CJ2));
if ind
%     disp('CJ2')
%     ind
   % CJ2(1)=CJ2(2);
%    CJ2(N)=CJ2(N-1);
     disp('nan, simulation paused CJ2')
     pause()
end