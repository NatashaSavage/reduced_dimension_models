%% plotting peak

load('output.mat')
% CC1S = load('data_C1_time_course_S1D');
% CC2S = load('data_C2_time_course_S1D');
% CC1 = load('data_C1_time_course_2D');
% CC2 = load('data_C2_time_course_2D');
% C11D = load('data_C1_time_course_1D');
% C21D = load('data_C2_time_course_1D');

load('CC1S')
load('CC2S')
load('CC2')
load('CC1')
load('C11D')
load('C21D')


figure
subplot(2,4,1);pcolor(C11D);shading flat
colormap(jet)
colorbar
title('C1 1D')
xlabel('Distance (um)')
ylabel('Time (s)')
xticks([1 N/2 N])
xticklabels({'0', '6', '12'})
c = colorbar;
c.Label.String = 'Protein Concentration (uM)';

subplot(2,4,5);pcolor(C21D);shading flat
colormap(jet)
colorbar
title('C2 1D')
xlabel('Distance (um)')
ylabel('Time (s)')
xticks([1 N/2 N])
xticklabels({'0', '6', '12'})
c = colorbar;
c.Label.String = 'Protein Concentration (uM)';

subplot(2,4,2);pcolor(CC1S);shading flat
colormap(jet)
colorbar
title('C1 Savage 1D')
xlabel('Distance (um)')
ylabel('Time (s)')
xticks([1 N/2 N])
xticklabels({'0', '6', '12'})
c = colorbar;
c.Label.String = 'Protein Concentration (uM)';

subplot(2,4,6);pcolor(CC2S);shading flat
colormap(jet)
colorbar
title('C2 Savage 1D')
xlabel('Distance (um)')
ylabel('Time (s)')
xticks([1 N/2 N])
xticklabels({'0', '6', '12'})
c = colorbar;
c.Label.String = 'Protein Concentration (uM)';

subplot(2,4,3);pcolor(CC1(N/2:N:end,:));shading flat
colormap(jet)
colorbar
title('C1 2D')
xlabel('Distance (um)')
ylabel('Time (s)')
xticks([1 N/2 N])
xticklabels({'0', '6', '12'})
c = colorbar;
c.Label.String = 'Protein Concentration (uM)';

subplot(2,4,7);pcolor(CC2(N/2:N:end,:));shading flat
colormap(jet)
colorbar
title('C2 2D')
xlabel('Distance (um)')
ylabel('Time (s)')
xticks([1 N/2 N])
xticklabels({'0', '6', '12'})
c = colorbar;
c.Label.String = 'Protein Concentration (uM)';

%%

subplot(2,4,4);hold
a3 = plot(C11D(end,:)); M3 = " 1D";
a1 = plot(C1S); M1 = "Savage 1D";
a2 = plot(C1(N/2,:)); M2 = "2D";
box 'on'
title('C1')
xlabel('Distance (um)')
ylabel('Protein Concentration (uM)')
xticks([1 N/2 N])
xticklabels({'0', '6', '12'})
legend([a3,a1,a2], [M3, M1, M2]);

subplot(2,4,8);hold
a3 = plot(C21D(end,:)); M3 = " 1D";
a1 = plot(C2S); M1 = "Savage 1D";
a2 = plot(C2(N/2,:)); M2 = "2D";
box 'on'
xlabel('Distance (um)')
ylabel('Protein Concentration (uM)')
xticks([1 N/2 N])
xticklabels({'0', '6', '12'})
legend([a3,a1,a2], [M3, M1, M2]);

