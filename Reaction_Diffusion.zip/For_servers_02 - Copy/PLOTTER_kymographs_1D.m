%% plotting peak

figure

cd Savage1D_2D_explicit_comparison_05b_03a_1D_splineFL_RD_04b
load('C11D')
cd ..


subplot(1,6,1);pcolor(C11D);shading flat
colormap(jet)
caxis([0 25]); ylim([0 900])
xticks([])
yticks([])
% colorbar
% title('C1 1D')
% xlabel('Distance (um)')
% ylabel('Time (s)')
% xticks([1 N/2 N])
% xticklabels({'0', '6', '12'})
% c = % colorbar;
% c.Label.String = 'Protein Concentration (uM)';


cd Savage1D_2D_explicit_comparison_05b_03a_1D_splineFL_RD_04a
load('C11D')
cd ..


subplot(1,6,2);pcolor(C11D);shading flat
colormap(jet)
caxis([0 25]); ylim([0 900])
xticks([])
yticks([])
% colorbar
% title('C1 1D')
% xlabel('Distance (um)')
% ylabel('Time (s)')
% xticks([1 N/2 N])
% xticklabels({'0', '6', '12'})
% c = % colorbar;
% c.Label.String = 'Protein Concentration (uM)';


cd Savage1D_2D_explicit_comparison_05b_03a_1D_splineFL_RD_04c
load('C11D')
cd ..


subplot(1,6,3);pcolor(C11D);shading flat
colormap(jet)
caxis([0 25]); ylim([0 900])
xticks([])
yticks([])
% colorbar
% title('C1 1D')
% xlabel('Distance (um)')
% ylabel('Time (s)')
% xticks([1 N/2 N])
% xticklabels({'0', '6', '12'})
% c = % colorbar;
% c.Label.String = 'Protein Concentration (uM)';


cd Savage1D_2D_explicit_comparison_05b_03a_1D_splineFL_RD_04d
load('C11D')
cd ..


subplot(1,6,4);pcolor(C11D);shading flat
colormap(jet)
caxis([0 25]); ylim([0 900])
xticks([])
yticks([])
% colorbar
% title('C1 1D')
% xlabel('Distance (um)')
% ylabel('Time (s)')
% xticks([1 N/2 N])
% xticklabels({'0', '6', '12'})
% c = % colorbar;
% c.Label.String = 'Protein Concentration (uM)';



cd Savage1D_2D_explicit_comparison_05b_03a_1D_splineFL_RD_04e
load('C11D')
cd ..


subplot(1,6,5);pcolor(C11D);shading flat
colormap(jet)
caxis([0 25]); ylim([0 900])
xticks([])
yticks([])
% colorbar
% title('C1 1D')
% xlabel('Distance (um)')
% ylabel('Time (s)')
% xticks([1 N/2 N])
% xticklabels({'0', '6', '12'})
% c = % colorbar;
% c.Label.String = 'Protein Concentration (uM)';


cd Savage1D_2D_explicit_comparison_05b_03a_1D_splineFL_RD_04f
load('C11D')
cd ..


subplot(1,6,6);pcolor(C11D);shading flat
colormap(jet)
caxis([0 25]); ylim([0 900])
xticks([])
yticks([])
% colorbar
% title('C1 1D')
% xlabel('Distance (um)')
% ylabel('Time (s)')
% xticks([1 N/2 N])
% xticklabels({'0', '6', '12'})
% c = % colorbar;
% c.Label.String = 'Protein Concentration (uM)';