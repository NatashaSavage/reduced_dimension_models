%% plotting peak

subplot(2,1,1);hold
for i = 1:6
    
    fplot(@(x) (0.5*i)*exp(-x^2),[-6 6],'LineWidth',1+i*0.2,'Color',[1-i*1.6/10 1-i*1.6/10 i*1.6/20])

    
end

subplot(2,1,2);hold
for i = 1:6
    
    fplot(@(x) 3-(0.5*i)*exp(-x^2),[-6 6],'LineWidth',1+i*0.2,'Color',[1-i*1.6/10 1-i*1.6/10 i*1.6/20])

    
end

