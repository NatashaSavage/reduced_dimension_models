%% plotting peak

figure

cd Savage1D_2D_explicit_comparison_05b_03a_1D_splineFL_RD_04b
load('CC1')
cd ..

figure
pcolor(CC1(N/2:N:end-N/2,:));shading flat
colormap(jet)
caxis([0 25]); ylim([0 900])
% colorbar
title('C1 1D')
xlabel('Distance (um)')
ylabel('Time (s)')
xticks([1 N/2 N])
xticklabels({'0', '6', '12'})
% c = % colorbar;
% c.Label.String = 'Protein Concentration (uM)';


cd Savage1D_2D_explicit_comparison_05b_03a_1D_splineFL_RD_04a
load('CC1')
cd ..

figure
pcolor(CC1(N/2:N:end-N/2,:));shading flat
colormap(jet)
caxis([0 25]); ylim([0 900])
% colorbar
title('C1 1D')
xlabel('Distance (um)')
ylabel('Time (s)')
xticks([1 N/2 N])
xticklabels({'0', '6', '12'})
% c = % colorbar;
% c.Label.String = 'Protein Concentration (uM)';


cd Savage1D_2D_explicit_comparison_05b_03a_1D_splineFL_RD_04c
load('CC1')
cd ..

figure
pcolor(CC1(N/2:N:end-N/2,:));shading flat
colormap(jet)
caxis([0 25]); ylim([0 900])
% colorbar
title('C1 1D')
xlabel('Distance (um)')
ylabel('Time (s)')
xticks([1 N/2 N])
xticklabels({'0', '6', '12'})
% c = % colorbar;
% c.Label.String = 'Protein Concentration (uM)';


cd Savage1D_2D_explicit_comparison_05b_03a_1D_splineFL_RD_04d
load('CC1')
cd ..

figure
pcolor(CC1(N/2:N:end-N/2,:));shading flat
colormap(jet)
caxis([0 25]); ylim([0 900])
% colorbar
title('C1 1D')
xlabel('Distance (um)')
ylabel('Time (s)')
xticks([1 N/2 N])
xticklabels({'0', '6', '12'})
% c = % colorbar;
% c.Label.String = 'Protein Concentration (uM)';



cd Savage1D_2D_explicit_comparison_05b_03a_1D_splineFL_RD_04e
load('CC1')
cd ..

figure
pcolor(CC1(N/2:N:end-N/2,:));shading flat
colormap(jet)
caxis([0 25]); ylim([0 900])
% colorbar
title('C1 1D')
xlabel('Distance (um)')
ylabel('Time (s)')
xticks([1 N/2 N])
xticklabels({'0', '6', '12'})
% c = % colorbar;
% c.Label.String = 'Protein Concentration (uM)';


cd Savage1D_2D_explicit_comparison_05b_03a_1D_splineFL_RD_04f
load('CC1')
cd ..

figure;
pcolor(CC1(N/2:N:end-N/2,:));shading flat
colormap(jet)
caxis([0 25]); ylim([0 900])
% colorbar
title('C1 1D')
xlabel('Distance (um)')
ylabel('Time (s)')
xticks([1 N/2 N])
xticklabels({'0', '6', '12'})
% c = % colorbar;
% c.Label.String = 'Protein Concentration (uM)';