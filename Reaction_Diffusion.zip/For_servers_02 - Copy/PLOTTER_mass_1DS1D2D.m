%% plotting peak in central slice

figure;hold
i = 0;

cd Savage1D_2D_explicit_comparison_05b_03a_1D_splineFL_RD_04b

M1D = load('data_mass_time_course_1D');
MS1D = load('data_mass_time_course_S1D');
M2D = load('data_mass_time_course_2D');

save M1D.mat M1D
save MS1D.mat MS1D
save M2D.mat M2D

i = i+1;
plot([0:3600],M1D,'LineWidth',1+i*0.2,'Color',[1-i*1.6/10 1-i*1.6/10 i*1.6/20])
plot([0:3600],MS1D,'LineWidth',1+i*0.2,'Color',[1-i*1.6/10 1-i*1.6/10 i*1.6/20])
plot([0:3600],M2D(:,2),'LineWidth',1+i*0.2,'Color',[1-i*1.6/10 1-i*1.6/10 i*1.6/20])

cd ..


cd Savage1D_2D_explicit_comparison_05b_03a_1D_splineFL_RD_04a

M1D = load('data_mass_time_course_1D');
MS1D = load('data_mass_time_course_S1D');
M2D = load('data_mass_time_course_2D');

save M1D.mat M1D
save MS1D.mat MS1D
save M2D.mat M2D

i = i+1;
plot([0:3600],M1D,'LineWidth',1+i*0.2,'Color',[1-i*1.6/10 1-i*1.6/10 i*1.6/20])
plot([0:3600],MS1D,'LineWidth',1+i*0.2,'Color',[1-i*1.6/10 1-i*1.6/10 i*1.6/20])
plot([0:3600],M2D(:,2),'LineWidth',1+i*0.2,'Color',[1-i*1.6/10 1-i*1.6/10 i*1.6/20])

cd ..


cd Savage1D_2D_explicit_comparison_05b_03a_1D_splineFL_RD_04c

M1D = load('data_mass_time_course_1D');
MS1D = load('data_mass_time_course_S1D');
M2D = load('data_mass_time_course_2D');

save M1D.mat M1D
save MS1D.mat MS1D
save M2D.mat M2D

i = i+1;
plot([0:3600],M1D,'LineWidth',1+i*0.2,'Color',[1-i*1.6/10 1-i*1.6/10 i*1.6/20])
plot([0:3600],MS1D,'LineWidth',1+i*0.2,'Color',[1-i*1.6/10 1-i*1.6/10 i*1.6/20])
plot([0:3600],M2D(:,2),'LineWidth',1+i*0.2,'Color',[1-i*1.6/10 1-i*1.6/10 i*1.6/20])

cd ..


cd Savage1D_2D_explicit_comparison_05b_03a_1D_splineFL_RD_04d

M1D = load('data_mass_time_course_1D');
MS1D = load('data_mass_time_course_S1D');
M2D = load('data_mass_time_course_2D');

save M1D.mat M1D
save MS1D.mat MS1D
save M2D.mat M2D

i = i+1;
plot([0:3600],M1D,'LineWidth',1+i*0.2,'Color',[1-i*1.6/10 1-i*1.6/10 i*1.6/20])
plot([0:3600],MS1D,'LineWidth',1+i*0.2,'Color',[1-i*1.6/10 1-i*1.6/10 i*1.6/20])
plot([0:3600],M2D(:,2),'LineWidth',1+i*0.2,'Color',[1-i*1.6/10 1-i*1.6/10 i*1.6/20])

cd ..


cd Savage1D_2D_explicit_comparison_05b_03a_1D_splineFL_RD_04e

M1D = load('data_mass_time_course_1D');
MS1D = load('data_mass_time_course_S1D');
M2D = load('data_mass_time_course_2D');

i = i+1;
save M1D.mat M1D
save MS1D.mat MS1D
save M2D.mat M2D

plot([0:3600],M1D,'LineWidth',1+i*0.2,'Color',[1-i*1.6/10 1-i*1.6/10 i*1.6/20])
plot([0:3600],MS1D,'LineWidth',1+i*0.2,'Color',[1-i*1.6/10 1-i*1.6/10 i*1.6/20])
plot([0:3600],M2D(:,2),'LineWidth',1+i*0.2,'Color',[1-i*1.6/10 1-i*1.6/10 i*1.6/20])

cd ..


cd Savage1D_2D_explicit_comparison_05b_03a_1D_splineFL_RD_04f

M1D = load('data_mass_time_course_1D');
MS1D = load('data_mass_time_course_S1D');
M2D = load('data_mass_time_course_2D');

save M1D.mat M1D
save MS1D.mat MS1D
save M2D.mat M2D

i = i+1;
plot([0:3600],M1D,'LineWidth',1+i*0.2,'Color',[1-i*1.6/10 1-i*1.6/10 i*1.6/20])
plot([0:3600],MS1D,'LineWidth',1+i*0.2,'Color',[1-i*1.6/10 1-i*1.6/10 i*1.6/20])
plot([0:3600],M2D(:,2),'LineWidth',1+i*0.2,'Color',[1-i*1.6/10 1-i*1.6/10 i*1.6/20])

cd ..