RUN_sausage_mesh_2D_05
%RUN_IC_exponential_stripe_sausage
PLOTTER_sausage

% grid around the sphere
hold
PLOTTER_grid

% % line around the sphere
% if 1
%     % hold
%     PLOTTER_circle
%     PLOTTER_circle2
% end