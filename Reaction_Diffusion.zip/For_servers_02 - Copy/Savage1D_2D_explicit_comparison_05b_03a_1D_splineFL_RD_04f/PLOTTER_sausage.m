

figure
surf([gridx,gridx(:,1)],[gridy,gridy(:,1)],[gridz,gridz(:,1)],[C1,C1(:,1)])
%         colormap('Winter')
%         caxis([-0.1 1.1])
        colormap('Jet')
        %caxis([0 10])
shading flat
axis equal
view(-15,60)
% grid off
% axis off
