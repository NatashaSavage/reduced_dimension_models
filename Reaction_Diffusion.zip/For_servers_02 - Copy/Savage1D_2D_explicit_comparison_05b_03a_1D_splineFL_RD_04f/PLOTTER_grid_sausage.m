%plot3(gridx(1,:),[gridy(:,60);gridy(end-1:-1:1,120)],[gridz(:,60);gridz(end-1:-1:1,60)])

for i = 1:1:60
    plot3(gridx(:,i),gridy(:,i),gridz(:,i),'b','LineWidth',0.5)
    plot3(gridx(:,60+i),gridy(:,60+i),gridz(:,60+i),'b','LineWidth',0.5)
end

for i = 1:1:70
    plot3(gridx(i,:),gridy(i,:),gridz(i,:),'b','LineWidth',0.5)
    
end