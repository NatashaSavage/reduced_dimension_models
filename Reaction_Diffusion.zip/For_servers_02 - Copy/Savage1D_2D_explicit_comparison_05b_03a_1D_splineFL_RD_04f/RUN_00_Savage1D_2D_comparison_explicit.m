%% Diffusion only program 
%  1D

%% Storage files
C1_storeS1D = fopen('data_C1_time_course_S1D',   'w');  % protein profile
C2_storeS1D = fopen('data_C2_time_course_S1D',   'w');  % protein profile
m_storeS1D  = fopen('data_mass_time_course_S1D', 'w');  % protein mass

C1_store2D = fopen('data_C1_time_course_2D',   'w');  % protein profile
C2_store2D = fopen('data_C2_time_course_2D',   'w');  % protein profile
m_store2D  = fopen('data_mass_time_course_2D', 'w');  % protein mass

C1_store1D = fopen('data_C1_time_course_1D',   'w');  % protein profile
C2_store1D = fopen('data_C2_time_course_1D',   'w');  % protein profile
m_store1D  = fopen('data_mass_time_course_1D', 'w');  % protein mass

T_store  = fopen('data_time_steps',   'w');  % protein profile time

% End storage files
%% Setting parameters & initial conditions

L    = 12;      % size of membrane (um)
Dx   = 0.1;     % grid size (um)
Dy   = 0.1;     % grid size (um)
N    = L/Dx;    % number of bins
M    = L/Dy;    % number of bins

DmC1 = 0.01;    % Diffusion coefficient ( (um^2)/s )
DmC2 = 1;     % Diffusion coefficient ( (um^2)/s )

Ttot = 60*60;     % Simulation time (s)
Dt   = 0.002;  % Time step
Ns   = Ttot/Dt;  % number of time steps in the simulation
Nr   = 200;
Dr   = Dt/Nr; 

mass = 3;
alpha = 3;

%% Diffusion

% Savage diffusion matrix C1
dxC1 = DmC1*Dt/(Dx^2);
dyC1 = DmC1*Dt/(Dy^2);
A = (1-2*dxC1)*eye(N);
Ap = dxC1*diag(ones(1,N-1),1);
Am = dxC1*diag(ones(1,N-1),-1);
A = A + Ap + Am;
A(1,N) = dxC1;
A(N,1) = dxC1;
AC1S = sparse(A);

% check for convergence 1D
if (2*dxC1 + dyC1) > 1
    disp('no convergence')
    disp('[dxC1, dyC1, (2*dxC1)+dyC1] = ')
    [dxC1, dyC1, (3*dxC1)]
end

% Savage diffusion matrix C2
dxC2 = DmC2*Dt/(Dx^2);
dyC2 = DmC2*Dt/(Dy^2);
A = (1-2*dxC2)*eye(N);
Ap = dxC2*diag(ones(1,N-1),1);
Am = dxC2*diag(ones(1,N-1),-1);
A = A + Ap + Am;
A(1,N) = dxC2;
A(N,1) = dxC2;
AC2S = sparse(A);

% check for convergence 1D
if (2*dxC2 + dyC2) > 1
    disp('no convergence')
    disp('[dxC2, dyC2, (2*dxC2)+dyC2] = ')
    [dxC2, dyC2, (3*dxC2)]
end

% 2D Diffusion  
dx2DC1 = DmC1*Dt/(Dx^2);
dy2DC1 = DmC1*Dt/(Dy^2);
dx2DC2 = DmC2*Dt/(Dx^2);
dy2DC2 = DmC2*Dt/(Dy^2);

% check for convergence 2D
if dx2DC1 + dy2DC1 > 0.5
    disp('no convergence, d <= 0.25')
    disp('dx2DC1 + dy2DC1 = ')
    [dx2DC1  dy2DC1]
end

if dx2DC2 + dy2DC2 > 0.5
    disp('no convergence, d <= 0.25')
    disp('dx2DC2 + dy2DC2 = ')
    [dx2DC2  dy2DC2]
end


%% Initial conditions 
T = 0;

% Savage 1D
% C1S      = zeros(N,1);
% % C1(3*N/4-5:3*N/4+5) = 3;
% % C1(1*N/4-5:1*N/4+5) = 3;
% C1S(N/2-5:N/2+5) = 3;
% C1totS = mass*ones(N,1);
% C2S   = C1totS - C1S;

C1S = alpha*exp(-(Dx*[1-N/2:1:N/2]').^2);
C2S   = mass-C1S;

RUN_write_to_files_savage_1D

C11D = C1S;
C21D = C2S;

RUN_write_to_files_1D

% 2D circle radius 11Dx/2 = 0.55
% XX = repmat(Dx*[1-N/2:1:N/2],N,1); 
% YY = repmat(Dy*[1-N/2:1:N/2]',1,N); 
% ind = find(sqrt(XX.^2 + YY.^2)<=0.55);
% C1      = zeros(N);
% C1(ind) = 3;
% C1tot = mass*ones(N);
% C2   = C1tot - C1;
% RUN_write_to_files_2D

% Distance of all bins from the centre 
% Distance of all bins from the centre
XX = repmat(Dx*[1-N/2:1:N/2] ,M,1);
YY = repmat(Dy*[1-M/2:1:M/2]',1,N);
% Concentration in 2D 
C1 = alpha*exp(-(XX.^2)-(YY.^2)); % initial condition
C2   = mass - C1;

RUN_write_to_files_2D

%% Savage Interpolation 

%% Interpolation mesh 
% The mesh we will be interpolating from.
%II =      Dx*[0.5-N/2:1:N/2-0.5];  
II =      Dx*[1-N/2:1:N/2];  

% the mesh we will be interpolating to
% Distance from the center, of all points in the Y = k+1(
% or k-1) plane. 
lz = sqrt(II.^2 + Dy^2);
                

%% Interpolating

RUN_interpolation 

%%



% End of setting parameters & initial conditions
%% Time stepping


for i = 1:Ns
    
    for ijk = 1:Nr
    
        % reaction S1D
        C1n = C1S + Dr*(1*(C1S.^2).*C2S - 1*C1S);
        C2n = C2S - Dr*(1*(C1S.^2).*C2S - 1*C1S);
        C1S = C1n;
        C2S = C2n;

        % reaction 2D
        C1n = C1 + Dr*(1*(C1.^2).*C2 - 1*C1);
        C2n = C2 - Dr*(1*(C1.^2).*C2 - 1*C1);   
        C1 = C1n;
        C2 = C2n; 

        % reaction 1D
        C1n = C11D + Dr*(1*(C11D.^2).*C21D - 1*C11D);
        C2n = C21D - Dr*(1*(C11D.^2).*C21D - 1*C11D);
        C11D = C1n;
        C21D = C2n;    
    end
    
    RUN_interpolation    
    
    % Savage diffusion 
    C1S = AC1S*C1S + 2*dyC1*(CJ1'-C1S);
    C2S = AC2S*C2S + 2*dyC2*(CJ2'-C2S);
    

    
    % 1D diffusion 
    C11D = AC1S*C11D;
    C21D = AC2S*C21D;    
    
    % 2D diffusion
    [C1] = FUNCTION_2Ddiffusion(C1,dx2DC1,dy2DC1,N,M);
    [C2] = FUNCTION_2Ddiffusion(C2,dx2DC2,dy2DC2,N,M);
    
%     PLOTTER_interp_checker
    
    % write to files
    if mod(i*Dt,1) == 0
        T = i*Dt;
        RUN_write_to_files_savage_1D
        RUN_write_to_files_2D
        RUN_write_to_files_1D
        save output.mat
    end
    
end


%% End of time stepping

fclose all;