%% drawing all points on the sphere (full 2D system)
L    = 12;          % corcumferanceof membrane (um) 
r    = L/(2*pi);    % radius of sphere
DxDy = 0.1;         % This is the Dy we would like to compare 
                    % with ring simulation, and the Dx on the equater.
% Dz   = 2*r/120;     % vertical slices of sphere to define grid points
%                     % these will dictate the minimum Dy 
Dpi  = 2*pi/(L/DxDy);    % number of horizontal & vertical slices 

% calculate z first.
z = r*sin(Dpi*[(L/4/DxDy):(3*L/4/DxDy)])';

%z = [-r:Dz:r]';

theta = acos(z/r);
gridx = [];
gridy = [];
gridz = [];

% points in column 1 and end are equal (thy = 0 & 2pi)
% only need thy = 2pi for surface plot so don't have them in our grid
%for thy = 0:Dpi:2*pi
r = 6/pi;

for thy = 0:2*pi/120:2*pi-2*pi/120

    gridx = [gridx , r*sin(theta)*cos(thy)];
    gridy = [gridy , r*sin(theta)*sin(thy)];
    gridz = [gridz , z];
end





gx = gridx(31,:);
gy = gridy(31,:);
gz = gridz(31,:);

%plot3(gx,gy,gz)
%pause

% gx = [gx ; ones(70,1).*gridx(31,:)];
% gy = [gy ; ones(70,1).*gridy(31,:)];
% gz = [gz ; [-0.1:-0.1:-7]'.*ones(1,121)];

gx = [gx ; ones(119,1).*gridx(31,:)];
gy = [gy ; ones(119,1).*gridy(31,:)];
gz = [gz ; [-0.1:-0.1:-11.9]'.*ones(1,120)];

gridx = gx;
gridy = gy;
gridz = gz;

% figure
% surf(gx,gy,gz)
% axis equal

% % shading flat
% axis equal
% hold
% pause()
% plot3(gridx(:,end),gridy(:,end),gridz(:,end),'o')
% plot3(gridx(:,1),gridy(:,1),gridz(:,1),'x')
% plot3(gridx(:,2),gridy(:,2),gridz(:,2),'s')
% plot3(gridx(:,end-1),gridy(:,end-1),gridz(:,end-1),'s')

