%% plotting peak

N = 120;
figure;hold

cd Savage1D_2D_explicit_comparison_05b_03a_1D_splineFL_RD_04b
load C11D.mat
plot(C11D(end-(N/2),:))
cd ..

cd Savage1D_2D_explicit_comparison_05b_03a_1D_splineFL_RD_04a
load C11D.mat
plot(C11D(end-(N/2),:))
cd ..

cd Savage1D_2D_explicit_comparison_05b_03a_1D_splineFL_RD_04c
load C11D.mat
plot(C11D(end-(N/2),:))
cd ..

cd Savage1D_2D_explicit_comparison_05b_03a_1D_splineFL_RD_04d
load C11D.mat
plot(C11D(end-(N/2),:))
cd ..

cd Savage1D_2D_explicit_comparison_05b_03a_1D_splineFL_RD_04e
load C11D.mat
plot(C11D(end-(N/2),:))
cd ..

cd Savage1D_2D_explicit_comparison_05b_03a_1D_splineFL_RD_04f
load C11D.mat
plot(C11D(end-(N/2),:))
cd ..