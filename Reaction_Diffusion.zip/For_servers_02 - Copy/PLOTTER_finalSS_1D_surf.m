%% plotting peak

N = 120;
figure;hold
A = [];
B = [];
C = [];



cd Savage1D_2D_explicit_comparison_05b_03a_1D_splineFL_RD_04b
load C11D.mat
%plot3([0.1:0.1:12],0.5*ones(1,120),C11D(end,:),'k')
scatter3([0.1:0.1:12],3.5+0.5*ones(1,120),C11D(end,:),500,C11D(end,:),'filled')
cd ..

A = [A;[0.1:0.1:12]];
B = [B; 0.5*ones(1,120)];
C = [C; C11D(end,:)];

cd Savage1D_2D_explicit_comparison_05b_03a_1D_splineFL_RD_04a
load C11D.mat
%plot3([0.1:0.1:12],ones(1,120),C11D(end,:),'k')
scatter3([0.1:0.1:12],3.5+ones(1,120),C11D(end,:),500,C11D(end,:),'filled')
cd ..

A = [A;[0.1:0.1:12]];
B = [B; 1*ones(1,120)];
C = [C; C11D(end,:)];

cd Savage1D_2D_explicit_comparison_05b_03a_1D_splineFL_RD_04c
load C11D.mat
% plot3([0.1:0.1:12],1.5*ones(1,120),C11D(end,:),'k')
scatter3([0.1:0.1:12],3.5+1.5*ones(1,120),C11D(end,:),500,C11D(end,:),'filled')
cd ..

A = [A;[0.1:0.1:12]];
B = [B; 1.5*ones(1,120)];
C = [C; C11D(end,:)];

cd Savage1D_2D_explicit_comparison_05b_03a_1D_splineFL_RD_04d
load C11D.mat
% plot3([0.1:0.1:12],2*ones(1,120),C11D(end,:),'k')
scatter3([0.1:0.1:12],3.5+2*ones(1,120),C11D(end,:),500,C11D(end,:),'filled')
cd ..

A = [A;[0.1:0.1:12]];
B = [B; 2*ones(1,120)];
C = [C; C11D(end,:)];

cd Savage1D_2D_explicit_comparison_05b_03a_1D_splineFL_RD_04e
load C11D.mat
% plot3([0.1:0.1:12],2.5*ones(1,120),C11D(end,:),'k')
scatter3([0.1:0.1:12],3.5+2.5*ones(1,120),C11D(end,:),500,C11D(end,:),'filled')
cd ..

A = [A;[0.1:0.1:12]];
B = [B; 2.5*ones(1,120)];
C = [C; C11D(end,:)];

cd Savage1D_2D_explicit_comparison_05b_03a_1D_splineFL_RD_04f
load C11D.mat
% plot3([0.1:0.1:12],3*ones(1,120),C11D(end,:),'k')
scatter3([0.1:0.1:12],3.5+3*ones(1,120),C11D(end,:),500,C11D(end,:),'filled')
cd ..

A = [A;[0.1:0.1:12]];
B = [B; 3*ones(1,120)];
C = [C; C11D(end,:)];

view(0,90)
colormap(jet)
caxis([0,15])
xticks([])
yticks([])
box on 