figure 
hold

cd torus_explicit
cd torus_explicit_02
m = load('data_C_time_course');
t = load('data_time_steps');
m = m(60:120:end,50:71);
m2D = mean(m');
plot(t,m2D)
cd ..
cd ..

cd ring_explicit
cd ring_explicit_01
m = load('data_C_time_course');
m1D = mean(m(:,50:71)');
plot(t,m1D)
cd ..
cd ..

cd unrestricted_explicit
cd dx_0p1_dy_0p1
m = load('data_C_time_course_1');
m1Due = mean(m(:,50:71)');
plot(t,m1Due)
cd ..
cd ..

cd unrestricted_semi_implicit
cd dx_0p1_dy_0p1
m = load('data_C_time_course_1');
m1Dui = mean(m(:,50:71)');
plot(t,m1Dui)
cd ..
cd ..

  m2D_F = (max(m2D)  -min(m2D))  /2;
  m1D_F = (max(m1D)  -min(m1D))  /2;
m1Due_F = (max(m1Due)-min(m1Due))/2;
m1Dui_F = (max(m1Dui)-min(m1Dui))/2;

x = [0:10];
xinterp = [0:0.001:10];

disp('2D')
yinterp = interp1(x,m2D(1:11),xinterp);
ind=find(yinterp>=min(m2D)+m2D_F);
xinterp(ind(1))

((1.1^2)+2)/(8*xinterp(ind(1)))



disp('1D')
yinterp = interp1(x,m1D(1:11),xinterp);
ind=find(yinterp>=min(m1D)+m1D_F);
xinterp(ind(1))

((1.1^2)+2)/(8*xinterp(ind(1)))


disp('1D e')
yinterp = interp1(x,m1Due(1:11),xinterp);
ind=find(yinterp>=min(m1Due)+m1Due_F);
xinterp(ind(1))

((1.1^2)+2)/(8*xinterp(ind(1)))


disp('1D i')
yinterp = interp1(x,m1Dui(1:11),xinterp);
ind=find(yinterp>=min(m1Dui)+m1Dui_F);
xinterp(ind(1))

((1.1^2)+2)/(8*xinterp(ind(1)))
