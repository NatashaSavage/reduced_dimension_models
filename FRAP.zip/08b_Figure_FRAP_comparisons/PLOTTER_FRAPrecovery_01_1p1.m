figure 
hold

cd torus_explicit
cd torus_explicit_02
m2 = load('data_C_time_course');
t = load('data_time_steps');
m = m2(60:120:end,55:66);
m2D = mean(m');

cd ..
cd ..

N = 120;
M = 120;
XX = repmat(0.1*[0.5-N/2:1:N/2-0.5] ,M,1);
YY = repmat(0.1*[  1-M/2:1:M/2    ]',1,N);
% Concentration in 2D 
ind = find(((XX.^2)+(YY.^2)).^0.5<=0.55); % initial condition
m2D2 = nan(1,301);
for i = 0:300
    m = m2(1+(i*120):((i+1)*120),:);
    m2D2(i+1)=mean(m(ind));
end
plot(t,m2D2)
pause()
plot(t,m2D)
pause()

cd ring_explicit
%cd ring_explicit_01_D_0p22
cd ring_explicit_01_D_0p1
m = load('data_C_time_course');
m1D = mean(m(:,55:66)');
plot(t,m1D)
cd ..
cd ..
pause()
cd unrestricted_explicit
cd dx_0p1_dy_0p1
m = load('data_C_time_course_1');
m1Due = mean(m(:,55:66)');
plot(t,m1Due)
cd ..
cd ..
pause()
cd unrestricted_semi_implicit
cd dx_0p1_dy_0p1
m = load('data_C_time_course_1');
m1Dui = mean(m(:,55:66)');
plot(t,m1Dui)
cd ..
cd ..

  m2D_F = (max(m2D)  -min(m2D))  /2;
 m2D2_F = (max(m2D2) -min(m2D2)) /2;  
  m1D_F = (max(m1D)  -min(m1D))  /2;
m1Due_F = (max(m1Due)-min(m1Due))/2;
m1Dui_F = (max(m1Dui)-min(m1Dui))/2;

x = [0:10];
xinterp = [0:0.001:10];

disp('2D')
yinterp = interp1(x,m2D(1:11),xinterp);
ind=find(yinterp>=min(m2D)+m2D_F);
xinterp(ind(1))

((0.55^2)+2)/(8*xinterp(ind(1)))

disp('2D.2')
yinterp = interp1(x,m2D2(1:11),xinterp);
ind=find(yinterp>=min(m2D2)+m2D2_F);
xinterp(ind(1))

((0.55^2)+2)/(8*xinterp(ind(1)))


disp('1D')
yinterp = interp1(x,m1D(1:11),xinterp);
ind=find(yinterp>=min(m1D)+m1D_F);
xinterp(ind(1))

((0.55^2)+2)/(8*xinterp(ind(1)))


disp('1D e')
yinterp = interp1(x,m1Due(1:11),xinterp);
ind=find(yinterp>=min(m1Due)+m1Due_F);
xinterp(ind(1))

((0.55^2)+2)/(8*xinterp(ind(1)))


disp('1D i')
yinterp = interp1(x,m1Dui(1:11),xinterp);
ind=find(yinterp>=min(m1Dui)+m1Dui_F);
xinterp(ind(1))

((0.55^2)+2)/(8*xinterp(ind(1)))
