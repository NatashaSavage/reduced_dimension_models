%% 2D 2.2

cd torus_explicit
cd torus_explicit_02_uniform_2p2
m = load('data_C_time_course');
t = load('data_time_steps');
m = m(60:120:end,50:71);
m2D = mean(m');
%plot(t,m2D)
cd ..
cd ..

m2D_F = (max(m2D)  -min(m2D))  /2;

x = [0:5];
xinterp = [0:0.001:5];

yinterp = interp1(x,m2D(1:6),xinterp);
ind=find(yinterp>=m2D_F);
xinterp(ind(1))

0.224*(1.1^2)/xinterp(ind(1))

%% 2D 1.1

cd torus_explicit
cd torus_explicit_02_uniform_1p1
m = load('data_C_time_course');
t = load('data_time_steps');
m = m(60:120:end,55:66);
m2D = mean(m');
%plot(t,m2D)
cd ..
cd ..

m2D_F = (max(m2D)  -min(m2D))  /2;

x = [0:5];
xinterp = [0:0.001:5];

yinterp = interp1(x,m2D(1:6),xinterp);
ind=find(yinterp>=m2D_F);
xinterp(ind(1))

0.224*(0.55^2)/xinterp(ind(1))

%%

% cd ring_explicit
% cd ring_explicit_01
% m = load('data_C_time_course');
% m1D = mean(m(:,55:66)')
% plot(t,m1D)
% cd ..
% cd ..
% 
% cd unrestricted_explicit
% cd dx_0p1_dy_0p1
% m = load('data_C_time_course_1');
% m1Due = mean(m(:,55:66)');
% plot(t,m1Due)
% cd ..
% cd ..
% 
% cd unrestricted_semi_implicit
% cd dx_0p1_dy_0p1
% m = load('data_C_time_course_1');
% m1Dui = mean(m(:,55:66)');
% plot(t,m1Dui)
% cd ..
% cd ..
% 
%   m2D_F = (max(m2D)  -min(m2D))  /2;
%   m1D_F = (max(m1D)  -min(m1D))  /2;
% m1Due_F = (max(m1Due)-min(m1Due))/2;
% m1Dui_F = (max(m1Dui)-min(m1Dui))/2;
% 
% x = [0:5];
% xinterp = [0:0.001:5];
% 
% yinterp = interp1(x,m2D(1:6),xinterp);
% ind=find(yinterp>=m2D_F);
% xinterp(ind(1))
% 
% ((1.1^2)+2)/(8*xinterp(ind(1)))
% 0.224*(1.1^2)/xinterp(ind(1))
% 
% yinterp = interp1(x,m1D(1:6),xinterp);
% ind=find(yinterp>=m1D_F);
% xinterp(ind(1))
% 
% ((1.1^2)+2)/(8*xinterp(ind(1)))
% 0.224*(1.1^2)/xinterp(ind(1))
% 
% yinterp = interp1(x,m1Due(1:6),xinterp);
% ind=find(yinterp>=m1Due_F);
% xinterp(ind(1))
% 
% ((1.1^2)+2)/(8*xinterp(ind(1)))
% 0.224*(1.1^2)/xinterp(ind(1))
% 
% yinterp = interp1(x,m1Dui(1:6),xinterp);
% ind=find(yinterp>=m1Dui_F);
% xinterp(ind(1))
% 
% ((1.1^2)+2)/(8*xinterp(ind(1)))
% 0.224*(1.1^2)/xinterp(ind(1))