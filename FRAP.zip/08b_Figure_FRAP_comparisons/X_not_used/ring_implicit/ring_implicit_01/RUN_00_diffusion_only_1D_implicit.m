%% Diffusion only program 
%  1D

%% Storage files
C_store = fopen('data_C_time_course',   'w');  % protein profile
m_store = fopen('data_mass_time_course','w');  % protein mass

% End storage files
%% Setting parameters & initial conditions

L    = 12;      % size of membrane (um)
N    = 120;     % number of bins
Dx   = L/N;     % grid size (um)
Dm   = 0.1;     % Diffusion coefficient ( (um^2)/s )
Ttot = 5*60;      % Simulation time (s)
Dt   = 0.1;    % Time step
Ns   = Ttot/Dt; % number of time steps in the simulation
    
% Diffusion matrix 
d = Dm*Dt/(Dx^2);
A = (1+2*d)*eye(N);
Ap = -d*diag(ones(1,N-1),1);
Am = -d*diag(ones(1,N-1),-1);
A = A + Ap + Am;
A(1,N) = -d;
A(N,1) = -d;
A = sparse(A);

% Initial conditions 
C = 1-exp(-(Dx*[0.5-N/2:1:N/2-0.5]').^2);


% End of setting parameters & initial conditions
%% Time stepping

%figure
%PLOTTER_peak
RUN_write_to_files_1D

for i = 1:Ns
    
    % diffuson
    C = A\C;
    
    if mod(i*Dt,1) == 0
        %PLOTTER_peak_1D
        RUN_write_to_files_1D
        save output.mat
    end
    
end

%% End of time stepping