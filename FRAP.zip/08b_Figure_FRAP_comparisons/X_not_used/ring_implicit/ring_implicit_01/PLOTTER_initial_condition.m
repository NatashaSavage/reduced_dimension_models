
load('output.mat')
CC = load('data_C_time_course');
figure
plot(Dx*[0.5:N],CC(1,:))