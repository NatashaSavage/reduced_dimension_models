%% plotting peak

load('output.mat')
CC = load('data_C_time_course');
figure
pcolor(CC);shading flat
caxis([0,1])
colormap(jet)
title('Diffusion in 1D')
xlabel('Distance (um)')
ylabel('Time (s)')
xticks([1 N/2 N])
xticklabels({'0', '5', '10'})
c = colorbar;
c.Label.String = 'Protein Concentration (uM)';