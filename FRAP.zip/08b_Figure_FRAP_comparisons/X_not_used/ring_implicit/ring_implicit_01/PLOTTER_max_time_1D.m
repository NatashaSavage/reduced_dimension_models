%% plotting max

load('output.mat')
CC = load('data_C_time_course');
figure
plot([0:length(CC(:,N/2))-1],CC(:,N/2))
% axis([1,N,0,20])
title('Diffusion in 1D, max concentration')
ylabel('Protein Concentration (uM)')
xlabel('Time (s)')
% xticks([1 N/2 N])
% xticklabels({'0', '5', '10'})
