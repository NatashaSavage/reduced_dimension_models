%% plotting max 

load('output.mat')
CC = load('data_C_time_course');
T  = load('data_time_steps');

figure
%plot([0:300],CC(N/2:N:end,N/2))
plot(T',CC(N/2:N:end,N/2))
% axis([1,N,0,20])
title('Diffusion in 2D, max concentration')
ylabel('Protein Concentration (uM)')
xlabel('Time (s)')
% xticks([1 N/2 N])
% xticklabels({'0', '5', '10'})
