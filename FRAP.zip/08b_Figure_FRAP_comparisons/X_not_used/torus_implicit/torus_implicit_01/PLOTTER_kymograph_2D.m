%% plotting peak in central slice

load('output.mat')
CC = load('data_C_time_course');

figure
pcolor(CC(N/2:N:end,:));shading flat
caxis([0,1])
colormap(jet)
title('Diffusion in 2D')
ylabel('Time (s)')
xlabel('Distance (um)')
xticks([1 N/2 N])
xticklabels({'0', '5', '10'})
c = colorbar;
c.Label.String = 'Protein Concentration (uM)';

