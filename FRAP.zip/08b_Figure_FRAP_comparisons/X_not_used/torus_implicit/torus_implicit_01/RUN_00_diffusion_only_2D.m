%% Diffusion only program 
%  1D

%% Storage files
C_store = fopen('data_C_time_course',   'w');  % protein profile
m_store = fopen('data_mass_time_course','w');  % protein mass
T_store = fopen('data_time_steps',   'w');  % protein profile time

% End storage files
%% Setting parameters & initial conditions

L    = 12;      % size of membrane (um)
N    = 120;     % number of bins
Dx   = L/N;     % grid size (um)
Dm   = 0.1;     % Diffusion coefficient ( (um^2)/s )
Ttot = 5*60;    % Simulation time (s)
Dt   = 0.1;    % Time step
Ns   = Ttot/Dt; % number of time steps in the simulation
    
% Diffusion matrix 
RUN_2D_Diffusion_Matrix_implicit

% % check for convergence 1D
% if d > 0.5
%     disp('no convergence')
%     disp('Dm*Dt/(Dx^2) = ')
%     d
% end

XX = repmat(Dx*[0.5-N/2:1:N/2-0.5] ,N,1);
YY = repmat(Dy*[  1-N/2:1:N/2    ]',1,N);
% Initial conditions: patch
C = 1-exp(-(XX).^2 - (YY).^2);


% pcolor(C);shading flat
% pause()

% End of setting parameters & initial conditions
%% Time stepping

%figure
%PLOTTER_peak_central_slice
%PLOTTER_2D_profile
T = 0;
RUN_write_to_files_2D

for i = 1:Ns
    
    % Diffusing
    Cr = reshape(C',[N^2,1]);
    Cr = A\Cr;
    C  = reshape(Cr,[N,N])';
    
    if mod(i*Dt,1) == 0
        T = i*Dt;
        %PLOTTER_peak_central_slice
        %PLOTTER_2D_profile
        RUN_write_to_files_2D
        save output.mat
    end
    
end

%% End of time stepping

fclose all