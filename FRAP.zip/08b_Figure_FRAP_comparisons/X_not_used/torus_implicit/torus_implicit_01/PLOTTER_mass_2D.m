%% plotting peak in central slice

M = load('data_mass_time_course');
T  = load('data_time_steps');



figure; hold
plot(T,M(:,2))




