figure 
hold

cd torus_explicit
cd torus_explicit_02
m = load('data_C_time_course');
t = load('data_time_steps');
plot(t,m(60:120:end,60))
cd ..
cd ..

cd ring_explicit
cd ring_explicit_01_D_0p1
m = load('data_C_time_course');
plot(t,m(:,60))
cd ..
cd ..

cd unrestricted_explicit
cd dx_0p1_dy_0p1
m = load('data_C_time_course_1');
plot(t,m(:,60))
cd ..
cd ..

cd unrestricted_semi_implicit
cd dx_0p1_dy_0p1
m = load('data_C_time_course_1');
plot(t,m(:,60))
cd ..
cd ..